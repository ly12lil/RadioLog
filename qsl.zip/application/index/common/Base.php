<?php
/**
 * Created by PhpStorm.
 * User: administator
 * Date: 2018/10/16
 * Time: 9:15
 */

namespace app\index\common;


use think\Controller;

class Base extends Controller
{
    protected function initialize()
    {

    }

}