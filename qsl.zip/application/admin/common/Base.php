<?php
/**
 * Created by PhpStorm.
 * User: administator
 * Date: 2018/10/16
 * Time: 10:20
 */

namespace app\admin\common;


use think\Controller;

class Base extends Controller
{
    protected function initialize()
    {

    }
}