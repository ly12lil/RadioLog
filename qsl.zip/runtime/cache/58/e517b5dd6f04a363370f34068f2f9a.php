<?php
//000000000000
 exit();?>
think_serialize:a:17:{s:2:"id";i:84;s:11:"d_call_sign";s:6:"BG5FPQ";s:8:"d_device";s:4:"UV5R";s:7:"d_power";s:2:"5W";s:8:"d_signal";s:2:"59";s:6:"j_rate";s:6:"435Mhz";s:8:"j_device";s:4:"UV5R";s:7:"j_power";s:2:"5W";s:8:"j_signal";s:2:"59";s:5:"relay";s:12:"徐州中继";s:4:"date";s:10:"2018-10-17";s:6:"remark";s:12:"测试信息";s:6:"status";i:1;s:2:"pv";i:1;s:11:"create_time";s:10:"1539755923";s:11:"update_time";s:10:"1539755923";s:9:"unique_id";s:11:"5bc6cf93222";}