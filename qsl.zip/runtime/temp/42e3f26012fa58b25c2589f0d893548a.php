<?php /*a:1:{s:59:"C:\xampp\htdocs\qsl\application\index\view\index\index.html";i:1539752713;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BGXXX 的通联日志</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/css/amazeui.min.css">
    <link rel="stylesheet" href="<?php echo htmlentities(app('request')->root(true)); ?>/html/css/common.css">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/js/amazeui.min.js"></script>
    <style>
        .am-table tr:hover{
            background-color: #eeeeee;
        }
    </style>
</head>
<body>
        <header class="am-topbar am-topbar-inverse am-container">
                    <h1 class="am-topbar-brand">
                            <a href="#"><img class="logo" src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1539616061315&di=bd90e9c96a650bff7cdf8ce19f32c9a5&imgtype=0&src=http%3A%2F%2Ffujian.aidonghai.com%2Fforum%2F201504%2F29%2F182008mkx6w7f3s33arf5s.png" alt="" srcset=""></a>
                          </h1>
                          <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-secondary am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse-2'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
                        
                          <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse-2">
                            <ul class="am-nav am-nav-pills am-topbar-nav">
                                <li><a href="<?php echo url('index/index/index'); ?>">首页</a></li>
                                <li><a href="<?php echo url('index/index/discuss'); ?>">留言版</a></li>
                              <li class="am-dropdown" data-am-dropdown>
                               
                              </li>
                            </ul>
                        
                            <form class="am-topbar-form am-topbar-left am-form-inline" role="search" action="<?php echo url('index/index/index'); ?>" method="get">
                              <div class="am-form-group">
                                <input type="text" class="am-form-field am-input-sm" name="k" placeholder="搜索呼号">
                              </div>
                            </form>
                        
                            <div class="am-topbar-right">
                              <div class="am-dropdown" data-am-dropdown="{boundary: '.am-topbar'}">
                                <button class="am-btn am-btn-secondary am-topbar-btn am-btn-sm am-dropdown-toggle" data-am-dropdown-toggle>其他 <span class="am-icon-caret-down"></span></button>
                                <ul class="am-dropdown-content">
                                    <?php if(app('session')->get('user_name') !== null): ?>
                                    <li><a href="<?php echo url('admin/index/index'); ?>">进入后台</a></li>
                                    <li><a href="<?php echo url('admin/login/out'); ?>">退出</a></li>
                                    <?php else: ?>
                                    <li><a href="<?php echo url('admin/login/index'); ?>">登录</a></li>
                                    <?php endif; ?>
                                </ul>
                              </div>
                            </div>
                          </div>
              </header>


            <section class="am-container " style="padding:0">
                    <div class="am-panel am-panel-primary">
                            <div class="am-panel-hd">
                              <h3 class="am-panel-title">通联日志</h3>
                            </div>
                            <div class="am-panel-bd">
                              <p>这里是xxx的通联日志</p>
                            </div>
                            <table class="am-table">
                                <thead>
                                    <tr><th>呼号</th><th>备注</th><th>日期</th><th>浏览量</th></tr>
                                </thead>
                                <tbody>
                                <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                <tr>
                                    <td><a href="page/<?php echo htmlentities($list['d_call_sign']); ?>/<?php echo htmlentities($list['unique_id']); ?>.html"><?php echo htmlentities($list['d_call_sign']); ?></a></td><td><?php echo htmlentities($list['remark']); ?></td><td><span class="am-badge am-badge-success"><?php echo htmlentities($list['pv']); ?></span></td><td><span class="am-badge am-badge-success"><?php echo htmlentities($list['date']); ?></span></td></tr>
                                </tr>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                </tbody>
                            </table>
                            <div class="am-panel-footer">
                                    <?php echo $data; ?>
                            </div>
                          </div>
            </section>
            <footer data-am-widget="footer"
            class="am-footer am-footer-default">
      <div class="am-footer-miscs ">
        <p>CopyRight©2018</p>
        <p>苏ICP备16003614号-1</p>
      </div>
    </footer>
  
    <div id="am-footer-modal"
         class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
      <div class="am-modal-dialog">
        <div class="am-modal-hd am-modal-footer-hd">
          <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
        </div>
    
      </div>
    </div>
   </body>
</html>