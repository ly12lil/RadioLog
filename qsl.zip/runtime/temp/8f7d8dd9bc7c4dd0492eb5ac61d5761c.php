<?php /*a:1:{s:61:"C:\xampp\htdocs\qsl\application\index\view\index\discuss.html";i:1539752701;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>留言板</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/css/amazeui.min.css">
    <link rel="stylesheet" href="<?php echo htmlentities(app('request')->root(true)); ?>/html/css/common.css">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/js/amazeui.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.js"></script>
</head>
<body>
        <header class="am-topbar am-topbar-inverse am-container">
                    <h1 class="am-topbar-brand">
                            <a href="#"><img class="logo" src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1539616061315&di=bd90e9c96a650bff7cdf8ce19f32c9a5&imgtype=0&src=http%3A%2F%2Ffujian.aidonghai.com%2Fforum%2F201504%2F29%2F182008mkx6w7f3s33arf5s.png" alt="" srcset=""></a>
                          </h1>
                          <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-secondary am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse-2'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
                        
                          <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse-2">
                            <ul class="am-nav am-nav-pills am-topbar-nav">
                                <li><a href="<?php echo url('index/index/index'); ?>">首页</a></li>
                                <li><a href="<?php echo url('index/index/discuss'); ?>">留言版</a></li>
                              <li class="am-dropdown" data-am-dropdown>
                               
                              </li>
                            </ul>
                        
                            <form class="am-topbar-form am-topbar-left am-form-inline" role="search">
                              <div class="am-form-group">
                                <input type="text" class="am-form-field am-input-sm" placeholder="搜索呼号">
                              </div>
                            </form>
                        
                            <div class="am-topbar-right">
                              <div class="am-dropdown" data-am-dropdown="{boundary: '.am-topbar'}">
                                <button class="am-btn am-btn-secondary am-topbar-btn am-btn-sm am-dropdown-toggle" data-am-dropdown-toggle>其他 <span class="am-icon-caret-down"></span></button>
                                <ul class="am-dropdown-content">
                                    <?php if(app('session')->get('user_name') !== null): ?>
                                    <li><a href="<?php echo url('admin/index/index'); ?>">进入后台</a></li>
                                    <li><a href="<?php echo url('admin/login/out'); ?>">退出</a></li>
                                    <?php else: ?>
                                    <li><a href="<?php echo url('admin/login/index'); ?>">登录</a></li>
                                    <?php endif; ?>
                                </ul>
                              </div>
                            </div>
                        
                            <!--<div class="am-topbar-right">-->
                              <!--<button class="am-btn am-btn-primary am-topbar-btn am-btn-sm">登录</button>-->
                            <!--</div>-->
                          </div>
              </header>
  
            <section class="am-container " style="padding:0">
                    <div class="am-panel am-panel-primary">
                            <div class="am-panel-hd">
                              <h3 class="am-panel-title">留言板</h3>
                            </div>
                            
                            
                      <div>

                          <!--PC和WAP自适应版-->
<div id="SOHUCS" sid="pl" ></div> 
<script type="text/javascript"> 
(function(){ 
var appid = 'cytRVrcKk'; 
var conf = 'prod_e975a85c82cad2e0e85e8a250f734a0c'; 
var width = window.innerWidth || document.documentElement.clientWidth; 
if (width < 960) { 
window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="https://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("https://changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>
                        
                      </div>
                          </div>
            </section>
            <footer data-am-widget="footer"
            class="am-footer am-footer-default">
      <div class="am-footer-miscs ">
          <p>CopyRight©2018</p>
          <p>苏ICP备16003614号-1</p>
      </div>
    </footer>
  
    <div id="am-footer-modal"
         class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
      <div class="am-modal-dialog">
        <div class="am-modal-hd am-modal-footer-hd">
          <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
        </div>
    
      </div>
    </div>
   </body>
</html>