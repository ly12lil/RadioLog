<?php /*a:1:{s:58:"C:\xampp\htdocs\qsl\application\index\view\index\page.html";i:1539755858;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo htmlentities($data['d_call_sign']); ?> - <?php echo htmlentities($data['date']); ?> 通联日志</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/css/amazeui.min.css">
    <link rel="stylesheet" href="<?php echo htmlentities(app('request')->root(true)); ?>/html/css/common.css">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery.print/1.5.1/jQuery.print.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/amazeui/2.7.2/js/amazeui.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.js"></script>
        
<script>
         $(document).ready(function () { 
            html2canvas($("#content")).then(canvas => {
              $('.qsl').attr('src',canvas.toDataURL("image/png"));
              $('#content').css('display','none');
            });
            
            $('#prt').click(function () {
                $(".qsl").print();
            })

          })
       </script>
</head>
<body>
        <header class="am-topbar am-topbar-inverse am-container">
                    <h1 class="am-topbar-brand">
                            <a href="#"><img class="logo" src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1539616061315&di=bd90e9c96a650bff7cdf8ce19f32c9a5&imgtype=0&src=http%3A%2F%2Ffujian.aidonghai.com%2Fforum%2F201504%2F29%2F182008mkx6w7f3s33arf5s.png" alt="" srcset=""></a>
                          </h1>
                          <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-secondary am-show-sm-only" data-am-collapse="{target: '#doc-topbar-collapse-2'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>
                        
                          <div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse-2">
                            <ul class="am-nav am-nav-pills am-topbar-nav">
                              <li><a href="<?php echo url('index/index/index'); ?>">首页</a></li>
                              <li><a href="<?php echo url('index/index/discuss'); ?>">留言版</a></li>
                              <li class="am-dropdown" data-am-dropdown>
                               
                              </li>
                            </ul>

                              <form class="am-topbar-form am-topbar-left am-form-inline" role="search" action="<?php echo url('index/index/index'); ?>" method="get">
                                  <div class="am-form-group">
                                      <input type="text" class="am-form-field am-input-sm" name="k" placeholder="搜索呼号">
                                  </div>
                              </form>

                            <div class="am-topbar-right">
                              <div class="am-dropdown" data-am-dropdown="{boundary: '.am-topbar'}">
                                <button class="am-btn am-btn-secondary am-topbar-btn am-btn-sm am-dropdown-toggle" data-am-dropdown-toggle>其他 <span class="am-icon-caret-down"></span></button>
                                <ul class="am-dropdown-content">
                                    <?php if(app('session')->get('user_name') !== null): ?>
                                    <li><a href="<?php echo url('admin/index/index'); ?>">进入后台</a></li>
                                    <li><a href="<?php echo url('admin/login/out'); ?>">退出</a></li>
                                    <?php else: ?>
                                    <li><a href="<?php echo url('admin/login/index'); ?>">登录</a></li>
                                    <?php endif; ?>
                                </ul>
                              </div>
                            </div>

                          </div>
              </header>
  
            <section class="am-container " style="padding:0">
                    <div class="am-panel am-panel-primary">
                            <div class="am-panel-hd">
                              <h3 class="am-panel-title">通联日志</h3>
                            </div>
                            <div class="am-panel-bd">
                              <p>QSL卡片</p>
                              <div id="content" class="clr" style="width:700px;height: 400px;position: relative;">
                                  <img src="<?php echo htmlentities(app('request')->root(true)); ?>/html/img/qsl.jpg" style="width:100%;height: 100%;" alt="" srcset="">
                                  <div style="position: absolute;top: 0;left: 0;bottom: 0;right: 0;z-index: 9999 ;">
                                      <h1 style="color:red;position: absolute;top: 55px;right: 105px;font-size:42px;"><?php echo htmlentities((isset($data['d_call_sign']) && ($data['d_call_sign'] !== '')?$data['d_call_sign']:'无')); ?></h1>
                                      <div>
                                          <span style="position: absolute;top: 210px;left: 68px;"><?php echo htmlentities((isset($data['date']) && ($data['date'] !== '')?$data['date']:'无')); ?></span>
                                          <span style="position: absolute;top: 210px;left: 282px;"><?php echo htmlentities((isset($data['j_rate']) && ($data['j_rate'] !== '')?$data['j_rate']:'无')); ?></span>
                                          <span style="position: absolute;top: 210px;left: 372px;"><?php echo htmlentities((isset($data['d_signal']) && ($data['d_signal'] !== '')?$data['d_signal']:'无')); ?></span>
                                          <span style="position: absolute;top: 210px;left: 430px;"><?php echo htmlentities((isset($data['remark']) && ($data['remark'] !== '')?$data['remark']:'无')); ?></span>
                                      </div>
                                  </div>
                              </div>
                              <img src="" alt="" class="qsl">
                                <button type="button" style="margin: 10px 0;float: right;" class="am-btn am-btn-secondary" id="prt">打印</button>
          
                            </div>
                            <table class="am-table am-table-bordered am-table-striped am-table-compact">
                                <thead>
                                  <th class="am-primary" colspan='4'>对方</th>
                                </thead>
                                <tbody>
                                <tr>
                                    <th>呼号</th>
                                    <th>设备</th>
                                    <th>功率</th>
                                    <th>信号</th>
                                </tr>
                                <tr>
                                  <td><?php echo htmlentities((isset($data['d_call_sign']) && ($data['d_call_sign'] !== '')?$data['d_call_sign']:'无')); ?></td>
                                  <td><?php echo htmlentities((isset($data['d_device']) && ($data['d_device'] !== '')?$data['d_device']:'无')); ?></td>
                                  <td><?php echo htmlentities((isset($data['d_power']) && ($data['d_power'] !== '')?$data['d_power']:'无')); ?></td>
                                  <td><?php echo htmlentities((isset($data['d_signal']) && ($data['d_signal'] !== '')?$data['d_signal']:'无')); ?></td>
                                </tr>
                                <thead>
                                    <th class="am-primary" colspan='4'>己方</th>
                                    <tr>
                                        <th>频率</th>
                                        <th>设备</th>
                                        <th>功率</th>
                                        <th>信号</th>
                                    </tr>
                                    <tr>
                                        <td><?php echo htmlentities((isset($data['j_rate']) && ($data['j_rate'] !== '')?$data['j_rate']:'无')); ?></td>
                                        <td><?php echo htmlentities((isset($data['j_device']) && ($data['j_device'] !== '')?$data['j_device']:'无')); ?></td>
                                        <td><?php echo htmlentities((isset($data['j_power']) && ($data['j_power'] !== '')?$data['j_power']:'无')); ?></td>
                                        <td><?php echo htmlentities((isset($data['j_signal']) && ($data['j_signal'] !== '')?$data['j_signal']:'无')); ?></td>
                                      </tr>
                                      <tr>
                                          <th>中继台</th>
                                          <td><?php echo htmlentities((isset($data['relay']) && ($data['relay'] !== '')?$data['relay']:'无')); ?></td>
                                          <th>时间</th>
                                          <td><?php echo htmlentities((isset($data['date']) && ($data['date'] !== '')?$data['date']:'无')); ?></td>
                                      </tr>
                                      <th class="am-primary" colspan='4'>备注</th>
                                      <tr>
                                      <td colspan='4'><?php echo htmlentities((isset($data['remark']) && ($data['remark'] !== '')?$data['remark']:'无')); ?></td>
                                    </tr>
                                  </thead>
                                </tbody>
                              </table>
                      <div>

                          <!--PC和WAP自适应版-->
<div id="SOHUCS" sid="<?php echo htmlentities((isset($data['unique_id']) && ($data['unique_id'] !== '')?$data['unique_id']:'无')); ?>" ></div>
<script type="text/javascript"> 
(function(){ 
var appid = 'cytRVrcKk'; 
var conf = 'prod_e975a85c82cad2e0e85e8a250f734a0c'; 
var width = window.innerWidth || document.documentElement.clientWidth; 
if (width < 960) { 
window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="https://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("https://changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })(); </script>
                        
                      </div>
                          </div>
            </section>
            <footer data-am-widget="footer"
            class="am-footer am-footer-default">
      <div class="am-footer-miscs ">
        <p>CopyRight©2018</p>
        <p>苏ICP备16003614号-1</p>
      </div>
    </footer>
  
    <div id="am-footer-modal"
         class="am-modal am-modal-no-btn am-switch-mode-m am-switch-mode-m-default">
      <div class="am-modal-dialog">
        <div class="am-modal-hd am-modal-footer-hd">
          <a href="javascript:void(0)" data-dismiss="modal" class="am-close am-close-spin " data-am-modal-close>&times;</a>
        </div>
    
      </div>
    </div>
   </body>
</html>